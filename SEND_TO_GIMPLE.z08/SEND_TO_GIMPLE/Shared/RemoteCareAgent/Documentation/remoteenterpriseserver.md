## Connection to Axeda

### Axeda

Login on https://leica-sandbox.axeda.com/drm/actions/index

### Create Action

Menu - Configuration on the right side.

* Select New -> Action

### File Download to Asset

* To configure an Action for the Upload/Download
  * Need current Java version

## Axeda Help Desk

URL: http://help.axeda.com

Login need to be registered

