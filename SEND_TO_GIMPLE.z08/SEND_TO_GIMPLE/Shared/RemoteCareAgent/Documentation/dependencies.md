
libssl-dev otherwise no HTTPS connection possible
AgentEmbedded 6.5-402 from Axeda ftp side - currently under ExternalPackage
