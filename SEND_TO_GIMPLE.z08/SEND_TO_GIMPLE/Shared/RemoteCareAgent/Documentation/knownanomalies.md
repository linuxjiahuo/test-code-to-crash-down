Legend: (x) - means is reported to axeda and is acknowledged

AgentEmbedded: 6.5-402

| Issue | Axeda acknowledged and case accepted | Additional info |
| ----- | ------------------------------------ | --------------- |
| Axeda - Download fails if device name has whitespace in the name | yes | N/A |
| RemoteSession not disappearing on the Web UI of Axeda | yes | N/A |

