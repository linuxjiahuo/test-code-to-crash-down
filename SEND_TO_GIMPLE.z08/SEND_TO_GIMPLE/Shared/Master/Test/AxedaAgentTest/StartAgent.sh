./AxedaAgent -g -s  https://leica-sandbox.axeda.com:443/eMessage

