## v1.1.2

* Remove whitespace from Device name for proper download and being independent from correct settings

## v1.1.1

* Reading DataItems type from xml file to be consistent with later changes

## v1.1

* AgentEmbedded 6.6-502

## v1.0

* AgentEmbedded 6.5-402
* CDD workflow integrated
* File download per callback with end callback
* File upload
* Read configuration from xml file
* RemoteSession request and permission based on configuration and hidding name as workaround for not hidden on RES
* DataItem usage as general interface between RES and Main SW
