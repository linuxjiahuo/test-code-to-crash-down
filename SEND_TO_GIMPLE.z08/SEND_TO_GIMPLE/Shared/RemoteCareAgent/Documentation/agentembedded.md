## AgentEmbedded

Compile under Platform/ExternalPackages

```
 make HOST=1
```

## Demo RemoteSession

./AeDemo1 -s -g -rsname " " -rshost 127.0.0.1 -rstype desktop -rsport 5900 https://leica-sandbox.axeda.com:443/eMessage

## Download Demo

./AeDemo4 -s -g https://leica-sandbox.axeda.com:443/eMessage

